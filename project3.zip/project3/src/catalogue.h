
#include <string.h>
#include <stdio.h>
#include <stdlib.h>



typedef struct
{
	char TYPE_OFFRE[100];
	char LOCALITE_OFFRE[100];
	char date_expiration[100];
	char PRIX[100];
	char QUANTITE[100];
	char IDENTIFIANT_OFFRE[100];



}offre;
void ajouter_o(offre o);
void afficher_o(GtkWidget *liste);
void modifier_o(offre o1);
void supprimer_o(char identifiant[]);
void verifier_os(char id_o[]);
int verifier_o(offre o1);
