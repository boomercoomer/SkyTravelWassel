#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "catalogue.h"


enum {
	
	TYPE_OFFRE,
	LOCALITE_OFFRE,
	date_expiration,
	PRIX,
	QUANTITE,
	IDENTIFIANT_OFFRE,
	COLUMNS
};

void ajouter(offre o)
{
	FILE *h;
	h=fopen("offre.txt","a+");
	if (h=!NULL)
		{fprintf(h,"%s %s %s %s %s %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE);
	fclose(h);
}

}
void afficher_o(GtkWidget *liste)
{	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char TYPE_OFFRE[20];
	char LOCALITE_OFFRE[100];
	char date_expiration[20];
	char PRIX[20];
	char QUANTITE[20];
	char IDENTIFIANT_OFFRE[20];
	store=NULL;

	FILE *h;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL) 

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("TYPE_OFFRE",renderer,"text",TYPE_OFFRE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("LOCALITE_OFFRE",renderer,"text",LOCALITE_OFFRE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("date_expiration",renderer,"text",date_expiration,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("PRIX",renderer,"text",PRIX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",QUANTITE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("IDENTIFIANT_OFFRE",renderer,IDENTIFIANT_OFFRE,TYPE_OFFRE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	h=fopen("offre.txt","r");
	if (h==NULL)
{
		return;
}
	else
		{	h=fopen("offre.txt","a+");
			while ((fscanf(h,"%s %s %s %s %S %s \n",TYPE_OFFRE,LOCALITE_OFFRE,date_expiration,PRIX,quantite,IDENTIFIANT_OFFRE)!=EOF);
			{

				gtk_list_store_append(store,&iter);
				gtk_list_store_set(store,&iter,TYPE_OFFRE,LOCALITE_OFFRE,date_expiration,PRIX,quantite,IDENTIFIANT_OFFRE,-1);
				
			}
			fclose(h);
			gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
			g_object_unref(store);
		}

}
int verifier_o(offre o1)
{
	FILE *k1;
	int test=0;
	k1=fopen("offre.txt","r");
	while (fscanf(k1,"%s %s %s %s %S %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE)!=EOF)
			{
				if (strcmp(o.IDENTIFIANT_OFFRE,o1.IDENTIFIANT_OFFRE)==0)
					test=1;
			}
			return test;
}
void modifier_o(offre o1)
{
	offre o;
	FILE *f1,*tmp;
	f1=fopen("offre.txt","r");
	tmp=fopen("offre.tmp.txt","a+");
	while(fscanf(f1,"%s %s %s %s %S %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE)!=EOF){
		if(strcmp(o.IDENTIFIANT_OFFRE,o1.IDENTIFIANT_OFFRE)==0){fprintf(tmp,"%s %s %s %s %S %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE)};
		else fprintf(tmp,"%s %s %s %s %S %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE);
	}
	fclose(f1);
	fclose(tmp);
	remove("offre.txt");
	rename("offre.tmp.txt","offre.txt");

}

int verifier_os(char id_o[]){
	offre o;
	FILE *k1;
	int testp=0;
	k1=fopen("offre.txt","r");
	while (fscanf(k1,"%s %s %s %s %S %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE))
		{

			if (strcmp(o.IDENTIFIANT_OFFRE,id_o)==0)
				testp=1;

		}
	fclose(k1);
	return testp;
}
void supprimer_o(char identifiant[])
{
	offre o;
	FILE *ff,*temp;
	ff=fopen("offre.txt","r");
	temp=fopen("offre.tmp.txt","a+");
	while (fscanf(ff,"%s %s %s %s %S %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE)!=EOF)
	{
		if (strcmp(o.IDENTIFIANT_OFFRE,identifiant)!=0){

			fprintf(temp,"%s %s %s %s %S %s \n",o.TYPE_OFFRE,o.LOCALITE_OFFRE,o.date_expiration,o.PRIX,o.QUANTITE,o.IDENTIFIANT_OFFRE);
		}}
	fclose(ff);
	fclose(temp);
	remove("offre.txt");
	rename("offre.tmp.txt","offre.txt");


	}


