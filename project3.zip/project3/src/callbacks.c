#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "callbacks.h"
#include "catalogue.h"

void on_ajouter_offre_clicked(GtkWidget *objet_graphique2,gpointer user_data)
{
	offre o;
	int testtest,E,N,T,P;
	char ma[50],mb[50];
	GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*joura,*moisa,*anneea;
	GtkWidget *Interface_agent;
	GtkWidget *output;
	Interface_agent=lookup_widget(objet_graphique2,"interface_agent");
	input1=lookup_widget(objet_graphique2,"combobox_type");
	input2=lookup_widget(objet_graphique2,"localite_offre");
	joura=lookup_widget(objet_graphique2,"spinbuttonJoura");
	moisa=lookup_widget(objet_graphique2,"spinbuttonAnneea");
	input3=lookup_widget(objet_graphique2,"prix");
	input4=lookup_widget(objet_graphique2,"spinbuttonQuantA");
	input5=lookup_widget(objet_graphique2,"identifiant_offre");

strcpy(o.TYPE_OFFRE,gtk_combo_box_get_active_text(GTK_CMBO_BOX(input1)));
strcpy(o.LOCALITE_OFFRE,gtk_entry_get_text(GTK_ENTRY(input2)));
E=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(joura));
N=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisa));
T=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneea));
sprintf(ma,"%d/%d/%d",E,N,T);
strcpy(o.date_expiration,ma);
strcpy(o.PRIX,gtk_entry_get_text(GTK_entry(input3)));
P=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
sprintf(mb,"%d",P);
strcpy(o.quantite,mb);
strcpy(o.identifiant_offre,gtk_entry_get_text(input5));
testtest=verifier_o(o);
if (testtest ==1 )
{output=lookup_widget(objet_graphique2,"labelmsg2");
gtk_label_set_text(GTK_LABEL(output,"IDENTIFIANT INCORRECTE"));
}
if (testtest==0)
	ajouter_o(o);



}

void on_afficher_offre_clicked(GtkWidget *objet_graphique2,gpointer user_data) {

	GtkWidget *FenetreCatalogue;
	GtkWidget *treeview1;
	FenetreCatalogue = lookup_widget(objet_graphique2,"type offre");
	treeview1=lookup_widget(FenetreCatalogue,"treeview1");
	afficher_o(treeview1);
}







