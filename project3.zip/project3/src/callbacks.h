
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


void on_ajouter_offre_clicked(GtkWidget *objet_graphique_2,gpointer user_data);
void on_afficher_offre_clicked(GtkWidget *objet_graphique2,gpointer user_data);
